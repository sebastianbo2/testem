import requestFiles from "./requestFiles"

const filePaths = ["cd2e11b9-11a2-45b7-8b91-fc3b3ac4cc31/Quiz_1.pdf__cacf681c-b942-42df-b64a-e591b75fbb8b.pdf",
  "18a7e07a-8ead-4b7f-9401-7809ce0707de/power series.pdf__ff1ca922-c0e0-45c1-a3b9-5c54634f9f23.pdf"
]

requestFiles(filePaths);