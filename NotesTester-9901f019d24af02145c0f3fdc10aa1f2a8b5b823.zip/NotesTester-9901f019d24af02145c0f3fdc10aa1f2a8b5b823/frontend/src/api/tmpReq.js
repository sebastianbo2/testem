import requestFiles from "./requestFiles.js";

const filePaths = [
  "indefinite integrals.pdf__bc0e46cf-87d8-407b-bcbe-61c07b886b78.pdf",
];

requestFiles(filePaths);
